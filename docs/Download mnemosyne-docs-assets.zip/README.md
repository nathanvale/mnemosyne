# Mnemosyne Docs – Static Assets

This folder contains image assets for your Docusaurus project, specifically for the Mnemosyne custom theme.

## 📁 Files Included

- `hero-mnemosyne.png`: The primary hero image used on the homepage.
  - Place this file in your Docusaurus static assets directory, typically `/static/assets/`.

## 🧠 Usage Instructions

1. Move `hero-mnemosyne.png` into `/static/assets/` of your Docusaurus project.
2. In your homepage component (e.g. `index.tsx`), reference it like so:

```tsx
<img src="/assets/hero-mnemosyne.png" alt="Mnemosyne Hero Image" />
```

3. Make sure the file path resolves correctly in dev and production builds.
4. You can also use this image in Open Graph tags or social previews.

Enjoy your beautifully themed docs ✨